
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Hello <?php echo e(Auth::user()->name); ?></h1>
<?php /**PATH C:\laragon\www\FirstProject\resources\views/home.blade.php ENDPATH**/ ?>