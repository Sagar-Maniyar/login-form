
@include('includes.header')
<h1>Hello {{ Auth::user()->name }}</h1>
